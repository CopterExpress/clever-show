import os
import sys

import csv
import json

import bpy
from bpy_extras.io_utils import ExportHelper
from bpy.types import Operator
from bpy.props import StringProperty, BoolProperty, FloatProperty, IntProperty


class ExportSwarmAnimation(Operator, ExportHelper):
    bl_idname = "swarm_anim.export"
    bl_label = "Export Drone Swarm animation"
    filename_ext = ''
    use_filter_folder = True

    filepath: StringProperty(
        name="File Path",
        description="File path used for exporting CSV files",
        maxlen=1024,
        subtype='DIR_PATH',
        default=""
    )

