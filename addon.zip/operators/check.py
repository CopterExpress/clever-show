import bpy
from bpy.types import Operator


class CheckSwarmAnimation(Operator):
    pass
