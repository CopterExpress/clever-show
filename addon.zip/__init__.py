import bpy
from bpy.utils import register_class, unregister_class
from bpy.types import PropertyGroup, PointerProperty, StringProperty
from . operators.export import ExportSwarmAnimation
from . operators.check import CheckSwarmAnimation

bl_info = {
    "name": "clever-show animation (.csv)",
    "author": "Artem Vasiunik & Arthur Golubtsov",
    "version": (0, 6, 1),
    "blender": (2, 83, 0),
    "location": "File > Export > clever-show animation (.csv)",
    "description": "Export > clever-show animation (.csv)",
    "doc_url": "https://github.com/CopterExpress/clever-show/blob/master/blender-addon/README.md",
    "tracker_url": "https://github.com/CopterExpress/clever-show/issues",
    "category": "Import-Export"
}


# noinspection PyArgumentList
class SwarmProperties(PropertyGroup):
    filter_obj: bpy.props.EnumProperty(
        name="Filter objects:",
        description="",
        items=[('all', "No filter (all objects)", ""),
               ('selected', "Only selected", ""),
               ('name', "By object name", ""),
               ('prop', "By object property", ""),
               ],
        default="selected"
    )

    drones_name: bpy.props.StringProperty(
        name="Name identifier",
        description="Name identifier for all drone objects",
        default="clever"
    )

    speed_limit: bpy.props.FloatProperty(
        name="Speed limit",
        description="Limit of drone movement speed (m/s)",
        unit='VELOCITY',
        default=3,
        min=0,
    )
    ddistance_limit: bpy.props.FloatProperty(
        name="Distance limit",
        description="Closest possible distance between drones (m)",
        unit='LENGTH',
        default=1.5,
        min=0,
    )


classes = (SwarmProperties,
           ExportSwarmAnimation, CheckSwarmAnimation)

def menu_func(self, context):
    self.layout.operator(
        ExportSwarmAnimation.bl_idname,
        text="clever-show animation (.csv)"
    )


def register():
    for cls in classes:

        register_class(cls)
    bpy.types.Scene.clever_swarm = PointerProperty(type=SwarmProperties)

    bpy.types.TOPBAR_MT_file_export.append(menu_func)


def unregister():
    for cls in reversed(classes):
        unregister_class(cls)
    del bpy.types.Scene.clever_swarm

    bpy.types.TOPBAR_MT_file_export.remove(menu_func)


if __name__ == "__main__":
    register()
